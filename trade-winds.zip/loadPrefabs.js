function loadPrefabs() {
	OS.AddScript("prefabs/shipPrefab.js");
	OS.AddScript("prefabs/islandPrefab.js");
	OS.AddScript("prefabs/oceanTilePrefab.js");
	OS.AddScript("prefabs/wavePrefab.js");
}
